export default function Header({ title }: {
    title?: string | undefined;
}): import("react/jsx-runtime").JSX.Element;
