export declare function sqr(num: number): number;
export declare function sum(num1: number, num2: number): number;
declare const utils: {
    sqr: typeof sqr;
    sum: typeof sum;
};
export default utils;
