declare const isValidEmail: (email: string) => boolean;
export default isValidEmail;
